#include <imgui.h>
#include <imgui-SFML.h>
#include <SFML/Graphics.hpp>
#include <iostream>



//////////////////////
// Initial defaults //
//////////////////////

// window
const char* window_title = "imgui-sfml";
const unsigned window_width = 800;
const unsigned window_height = 600;
const float max_frame_rate = 60;



////////////
// Events //
////////////

void handle_close (sf::RenderWindow& window)
{
    ImGui::SFML::Shutdown();
    window.close();
    exit (0);
}
void handle_resize (const sf::Event::Resized& resized, sf::RenderWindow& window)
{   // constrain aspect ratio and map always the same portion of the world
    float aspect = static_cast<float>(window_width)/static_cast<float>(window_height);
    sf::Vector2u ws = resized.size;
    float new_aspect = static_cast<float>(ws.x)/static_cast<float>(ws.y);
    if (new_aspect < aspect)
        ws = {ws.x,static_cast<unsigned>(ws.x/aspect)};
        else
        ws = {static_cast<unsigned>(ws.y*aspect),ws.y};
    window.setSize(ws);
}



//////////
// Loop //
//////////

int main()
{
    sf::RenderWindow window (sf::VideoMode ({window_width, window_height}), window_title);
    window.setFramerateLimit (max_frame_rate);
    window.setMinimumSize(window.getSize());
    if (!ImGui::SFML::Init(window)) {
        std::cerr << "Failure: could not init ImGui::SFML." << std::endl;
        return 1;
    }

    sf::Clock clock;
    while (window.isOpen())
    {
        while (const std::optional event = window.pollEvent()) {
            ImGui::SFML::ProcessEvent(window, *event);
            if (event->is<sf::Event::Closed>())
                handle_close (window);
            if (const auto* resized = event->getIf<sf::Event::Resized>())
                handle_resize (*resized, window);
        }

        sf::Time elapsed = clock.restart();

        ImGui::SFML::Update(window, elapsed);
        ImGui::ShowDemoWindow();
        ImGui::Begin("Hello, world!");
        ImGui::Button("Look at this pretty button");
        ImGui::End();

        window.clear (sf::Color::Black);

        float size = 50.0;
        sf::RectangleShape p ({size, size});
        float pos_x = window_width / 2.0 - size / 2.0;
        float pos_y = window_height / 2.0 - size / 2.0;
        p.setPosition ({pos_x, pos_y,});
        window.draw (p);

        ImGui::SFML::Render(window);
        window.display ();
    }

    return 0;
}
